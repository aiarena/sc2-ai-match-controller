## Test Bot
### Normal Bot Simulation

This is a normal bot that does an a-move worker rush on the first frame