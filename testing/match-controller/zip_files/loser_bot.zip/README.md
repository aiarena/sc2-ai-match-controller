## Test Bot
### Normal Bot Simulation

This is a normal bot that does nothing but mine minerals. 
This bot should lose against any other bot that attacks